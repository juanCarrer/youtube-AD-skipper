# youtube AD skipper
Extensión de Chrome para saltar publicidades automáticamente

## instalación
* Abre Chrome y escribe chrome://extensions/ en la barra de direcciones.
* Haz clic en el botón Modo de desarrollo.
* Haz clic en el botón Cargar descomprimida.
* Selecciona la carpeta que contiene la extensión desempaquetada.
* Haz clic en el botón Abrir.

La extensión se instalará y se activará automáticamente.
